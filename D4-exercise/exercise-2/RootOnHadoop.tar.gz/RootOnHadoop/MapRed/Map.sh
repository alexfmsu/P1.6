#!/bin/bash

echo ""
echo "Working on:"
echo $1
echo ""

echo "Access test:"
ls -lh $1
echo ""

echo "test!!" > test.out